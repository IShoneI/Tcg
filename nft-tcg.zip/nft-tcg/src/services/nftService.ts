import type { DASAsset, DASResponse, NFTCard } from "@/types/card";
import { calculateStats } from "@/engine/statEngine";

const HELIUS_API_KEY = process.env.NEXT_PUBLIC_HELIUS_API_KEY;
const HELIUS_RPC = `https://mainnet.helius-rpc.com/?api-key=${HELIUS_API_KEY}`;

// ---------------------------------------------------------------------------
// Low-level: Helius DAS fetch
// ---------------------------------------------------------------------------

/**
 * Fetch all NFTs owned by a wallet via Helius DAS API.
 */
export async function fetchNFTsByOwner(
  walletAddress: string,
  page: number = 1,
  limit: number = 1000
): Promise<DASResponse> {
  const response = await fetch(HELIUS_RPC, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "nft-tcg",
      method: "getAssetsByOwner",
      params: {
        ownerAddress: walletAddress,
        page,
        limit,
        displayOptions: {
          showCollectionMetadata: true,
          showUnverifiedCollections: false,
        },
      },
    }),
  });

  const { result, error } = await response.json();
  if (error) throw new Error(error.message || "DAS API error");
  return result;
}

/**
 * Fetch ALL pages for a wallet (handles >1000 NFT wallets).
 */
async function fetchAllNFTsByOwner(walletAddress: string): Promise<DASAsset[]> {
  const allAssets: DASAsset[] = [];
  let page = 1;
  const limit = 1000;

  while (true) {
    const result = await fetchNFTsByOwner(walletAddress, page, limit);
    allAssets.push(...result.items);
    if (allAssets.length >= result.total || result.items.length < limit) break;
    page++;
  }

  return allAssets;
}

// ---------------------------------------------------------------------------
// Filter
// ---------------------------------------------------------------------------

/**
 * Filter DAS assets by verified collection address.
 */
export function filterByCollection(
  assets: DASAsset[],
  collectionAddress: string
): DASAsset[] {
  return assets.filter((asset) =>
    asset.grouping.some(
      (g) => g.group_key === "collection" && g.group_value === collectionAddress
    )
  );
}

// ---------------------------------------------------------------------------
// Transform: DASAsset → NFTCard
// ---------------------------------------------------------------------------

/**
 * Convert a single DAS asset into a playable NFTCard.
 */
export function assetToCard(
  asset: DASAsset,
  holdDays: number = 0,
  overrides?: { isPFP?: boolean; costBasisSOL?: number; nickname?: string }
): NFTCard {
  const attributes = asset.content.metadata.attributes ?? [];
  const isPFP = overrides?.isPFP ?? false;
  const costBasisSOL = overrides?.costBasisSOL;

  const stats = calculateStats(attributes, holdDays, {
    isPFP,
    costBasisSOL,
  });

  const collectionGroup = asset.grouping.find(
    (g) => g.group_key === "collection"
  );

  return {
    id: asset.id,
    name: asset.content.metadata.name,
    image: asset.content.links?.image ?? "",
    collection: collectionGroup?.group_value ?? "",
    attributes,
    metadataUri: asset.content.json_uri,
    stats,
    holdDays,
    isPFP,
    costBasisSOL,
    nickname: overrides?.nickname,
  };
}

// ---------------------------------------------------------------------------
// High-level: Pluggable inventory loader
// ---------------------------------------------------------------------------

export interface LoadInventoryOptions {
  walletAddress: string;
  collectionAddress: string;

  /**
   * PLUGGABLE SOURCE: If provided, skips Helius fetch entirely.
   * Integration point for Clayno.club or any external provider
   * that supplies DASAsset-shaped data.
   *
   * Assets are still filtered by collectionAddress, so the
   * override can safely contain mixed-collection data.
   */
  inventoryOverride?: DASAsset[];

  /**
   * Pre-computed hold times: Map<mintAddress, days>.
   * If not provided, cards start with holdDays=0 and
   * hold times are patched in asynchronously.
   */
  holdTimes?: Map<string, number>;

  /**
   * Player overrides from localStorage (PFP, cost basis, nickname).
   */
  cardOverrides?: Record<
    string,
    { isPFP?: boolean; costBasisSOL?: number; nickname?: string }
  >;
}

/**
 * Load inventory → filter → transform → return NFTCards.
 *
 * Source priority:
 *   1. inventoryOverride (if provided) — e.g. from Clayno.club
 *   2. Helius DAS API getAssetsByOwner (default)
 */
export async function loadInventory(
  options: LoadInventoryOptions
): Promise<NFTCard[]> {
  const {
    walletAddress,
    collectionAddress,
    inventoryOverride,
    holdTimes,
    cardOverrides,
  } = options;

  // --- Step 1: Resolve source ---
  let allAssets: DASAsset[];

  if (inventoryOverride) {
    allAssets = inventoryOverride;
  } else {
    allAssets = await fetchAllNFTsByOwner(walletAddress);
  }

  // --- Step 2: Filter by collection ---
  const collectionAssets = filterByCollection(allAssets, collectionAddress);

  // --- Step 3: Transform to NFTCards ---
  const cards = collectionAssets.map((asset) => {
    const holdDays = holdTimes?.get(asset.id) ?? 0;
    const overrides = cardOverrides?.[asset.id];
    return assetToCard(asset, holdDays, overrides);
  });

  return cards;
}

// ---------------------------------------------------------------------------
// Extended metadata fetch (fallback)
// ---------------------------------------------------------------------------

export async function fetchFullMetadata(
  jsonUri: string
): Promise<Record<string, unknown>> {
  const response = await fetch(jsonUri);
  if (!response.ok)
    throw new Error(`Metadata fetch failed: ${response.status}`);
  return response.json();
}
