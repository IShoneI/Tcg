import type { PlayerProfile } from "@/types/card";

const STORAGE_PREFIX = "nft-tcg";

export function saveProfile(profile: PlayerProfile): void {
  const key = `${STORAGE_PREFIX}:${profile.walletAddress}`;
  localStorage.setItem(key, JSON.stringify(profile));
}

export function loadProfile(walletAddress: string): PlayerProfile | null {
  const key = `${STORAGE_PREFIX}:${walletAddress}`;
  const raw = localStorage.getItem(key);
  return raw ? JSON.parse(raw) : null;
}

export function createDefaultProfile(walletAddress: string): PlayerProfile {
  return {
    walletAddress,
    decks: [],
    matchHistory: [],
    cardOverrides: {},
    stats: {
      wins: 0,
      losses: 0,
      winStreak: 0,
      bestWinStreak: 0,
      totalBattles: 0,
    },
    lastUpdated: Date.now(),
  };
}

/**
 * Cache hold times so we don't re-fetch every session.
 */
export function saveHoldTimeCache(
  walletAddress: string,
  holdTimes: Record<string, number>
): void {
  const key = `${STORAGE_PREFIX}:holdtimes:${walletAddress}`;
  localStorage.setItem(
    key,
    JSON.stringify({ data: holdTimes, cachedAt: Date.now() })
  );
}

export function loadHoldTimeCache(
  walletAddress: string,
  maxAgeMs: number = 3_600_000 // 1 hour default
): Record<string, number> | null {
  const key = `${STORAGE_PREFIX}:holdtimes:${walletAddress}`;
  const raw = localStorage.getItem(key);
  if (!raw) return null;

  const { data, cachedAt } = JSON.parse(raw);
  if (Date.now() - cachedAt > maxAgeMs) return null;
  return data;
}
