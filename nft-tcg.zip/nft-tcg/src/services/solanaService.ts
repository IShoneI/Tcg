const HELIUS_API_KEY = process.env.NEXT_PUBLIC_HELIUS_API_KEY;
const HELIUS_REST = `https://api.helius.xyz/v0`;

/**
 * Get how many days the current owner has held this NFT.
 * Uses Helius parsed transaction history.
 */
export async function getHoldTimeDays(mintAddress: string): Promise<number> {
  try {
    // Check for most recent transfer TO current owner
    const transferRes = await fetch(
      `${HELIUS_REST}/addresses/${mintAddress}/transactions?api-key=${HELIUS_API_KEY}&type=TRANSFER&limit=1`
    );
    const transfers = await transferRes.json();

    if (transfers.length > 0) {
      const acquiredDate = new Date(transfers[0].timestamp * 1000);
      return Math.floor((Date.now() - acquiredDate.getTime()) / 86_400_000);
    }

    // No transfers = original holder since mint
    const mintRes = await fetch(
      `${HELIUS_REST}/addresses/${mintAddress}/transactions?api-key=${HELIUS_API_KEY}&type=NFT_MINT&limit=1`
    );
    const mintTxns = await mintRes.json();

    if (mintTxns.length > 0) {
      const mintDate = new Date(mintTxns[0].timestamp * 1000);
      return Math.floor((Date.now() - mintDate.getTime()) / 86_400_000);
    }

    return 0;
  } catch (err) {
    console.warn(`Hold time lookup failed for ${mintAddress}:`, err);
    return 0;
  }
}

/**
 * Batch hold time lookups with concurrency control.
 * Returns Map<mintAddress, holdDays>.
 */
export async function batchGetHoldTimes(
  mintAddresses: string[],
  concurrency: number = 5
): Promise<Map<string, number>> {
  const results = new Map<string, number>();
  const queue = [...mintAddresses];

  async function worker() {
    while (queue.length > 0) {
      const mint = queue.shift()!;
      const days = await getHoldTimeDays(mint);
      results.set(mint, days);
    }
  }

  const workers = Array.from({ length: concurrency }, () => worker());
  await Promise.all(workers);

  return results;
}
